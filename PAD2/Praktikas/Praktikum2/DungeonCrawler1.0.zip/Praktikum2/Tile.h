/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Tile.h
 * Author: stud
 *
 * Created on 25. April 2017, 13:00
 */

#ifndef TILE_H
#define TILE_H
#include <iostream>
#include "Character.h"

using namespace std;

class Tile
{
public:
    enum Typ{
        Floor,Wall,Finish
    };
    Tile(Typ t,Character* c);
    virtual ~Tile();
    
    void SetFigur(Character* figur);
    Character* GetFigur() const;
    Typ GetKachel() const;
    
    bool hasCharacter() const;
    void onLeave(Tile* toTile);
    void onEnter(Character* c, Tile* fromTile);
    
    void print();
    

private:
    Typ kachel;
    Character* figur=nullptr;
    
};

#endif /* TILE_H */

