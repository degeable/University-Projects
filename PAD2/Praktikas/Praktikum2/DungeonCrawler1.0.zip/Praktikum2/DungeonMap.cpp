/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   DungeonMap.cpp
 * Author: stud
 * 
 * Created on 25. April 2017, 13:20
 */

#include "DungeonMap.h"

DungeonMap::DungeonMap(int height, int width, Character* p,Position pos)
{

    m_height = height;
    m_width = width;
    m_map = new Tile**[height];
    
    
    for (auto i = 0; i < height; i++)
    {
        m_map[i] = new Tile*[width];
        for (auto j = 0; j < width; j++)
        {
            m_map[i][j] = new Tile(Tile::Floor, nullptr);
        }
    }
    
    m_map[pos.Reihe][pos.Spalte]->SetFigur(p);

}

DungeonMap::DungeonMap(int height, int width, const vector<string>& data, Character* p, Position pos)
{

    m_height = height;
    m_width = width;
    m_map = new Tile**[height];
    for (auto i = 0; i < height; i++)
    {
        m_map[i] = new Tile*[width];
        for (auto j = 0; j < width; j++)
        {
            if (data.at(i).at(j) == '.')
            {
                m_map[i][j] = new Tile(Tile::Floor, nullptr);
            }
            else if(data.at(i).at(j)== '#')
            {
                m_map[i][j] = new Tile(Tile::Wall, nullptr);
            }
            else if(data.at(i).at(j)== 'X')
            {
                m_map[i][j] = new Tile(Tile::Finish, nullptr);
            }
        }
    }
    m_map[pos.Reihe][pos.Spalte]->SetFigur(p);
}

DungeonMap::~DungeonMap()
{
    delete[] m_map;
    m_height = 0;
    m_width = 0;
}

Position DungeonMap::findCharacter(Character* c)
{
    for (auto i = 0; i < m_height; i++)
    {
        for (auto j = 0; j < m_width; j++)
        {
            if (m_map[i][j]->GetFigur() == c)
            {
                Position p;
                p.Reihe = i;
                p.Spalte = j;
                return p;
            }
        }
    }
    throw invalid_argument("out of range");
}

Position DungeonMap::findTile(Tile* t)
{
    for (auto i = 0; i < m_height; i++)
    {
        for (auto j = 0; j < m_width; j++)
        {
            if (m_map[i][j] == t)
            {
                Position p;
                p.Reihe = i;
                p.Spalte = j;
                return p;
            }
        }
    }
    throw invalid_argument("out of range");
}

Tile* DungeonMap::findTile(Position pos)
{
    if (pos.Reihe > m_height || pos.Spalte > m_width)
        throw out_of_range("Gesuchtes Tile außerhalb des Spielfelds");
    return m_map[pos.Reihe][pos.Spalte];
}

void DungeonMap::place(Position pos, Character* c)
{
    m_map[pos.Reihe][pos.Spalte]->SetFigur(c);
}

void DungeonMap::print()
{
    for (auto i = 0; i < m_height; i++)
    {
        for (auto j = 0; j < m_width; j++)
        {
            if (m_map[i][j]->hasCharacter())
            {
                cout << "O";
            }
            else if (m_map[i][j]->GetKachel() == Tile::Floor)
            {
                cout << ".";
            }
            else if (m_map[i][j]->GetKachel() == Tile::Wall)
            {
                cout << "#";
            }
            else if (m_map[i][j]->GetKachel() == Tile::Finish)
            {
                cout<<"X";
            }
                
                

        }
        cout << endl;

    }
    cout << endl << endl;
}
