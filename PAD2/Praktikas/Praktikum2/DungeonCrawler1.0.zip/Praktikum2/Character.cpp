/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Character.cpp
 * Author: stud
 * 
 * Created on 29. April 2017, 09:15
 */

#include "Character.h"

Character::Character(char f)
{
    m_figur=f;
}

char Character::getFigur() const
{
    return m_figur;
}

int Character::move()
{
    int m;
    cout<<"In welche Richtungs solls gehen? (1-9)"<<endl;
    cin>>m;
    return m;
}


