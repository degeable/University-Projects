/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   GameEngine.cpp
 * Author: stud
 * 
 * Created on 29. April 2017, 10:50
 */

#include "GameEngine.h"

GameEngine::GameEngine(int height, int width, const vector<string>& data, Character* p, Position pos)
: m_feld(DungeonMap(height, width, data, p, pos))
{

    m_figuren.push_back(p);
}

GameEngine::~GameEngine()
{
}

bool GameEngine::finished()
{
  if(m_feld.findTile(m_feld.findCharacter(m_figuren.at(0)))->GetKachel() == Tile::Finish){
        cout<<"Level Beendet!"<<endl;
     return true;
     
  }
      
    return false;
}



void GameEngine::turn()//Noch nicht implementiert....
{
    Position pos = m_feld.findCharacter(m_figuren.at(0));
    Tile* tmpTile = m_feld.findTile(pos);


    switch (m_figuren.at(0)->move())
    {
    case 1:
        pos.Reihe++;
        pos.Spalte--;
        break;
    case 2:
        pos.Reihe++;
        break;
    case 3:
        pos.Reihe++;
        pos.Spalte++;
        break;
    case 4:
        pos.Spalte--;
        break;
    case 5:
        break;
    case 6:
        pos.Spalte++;
        break;
    case 7:
        pos.Reihe--;
        pos.Spalte--;
        break;
    case 8:
        pos.Reihe--;
        break;
    case 9:
        pos.Reihe--;
        pos.Spalte++;
        break;
    }
    if (m_feld.findTile(pos)->GetKachel() == Tile::Wall)
    {
        m_feld.print();
    }
    else if ((m_feld.findTile(pos)->GetKachel() == Tile::Floor))
    {
        Tile* newTile = m_feld.findTile(pos);
        tmpTile->onLeave(newTile);
        m_feld.place(pos, m_figuren.at(0));
        m_feld.print();                  
    }
    else if ((m_feld.findTile(pos)->GetKachel() == Tile::Finish))
    {
        Tile* newTile = m_feld.findTile(pos);
        tmpTile->onLeave(newTile);
        m_feld.place(pos, m_figuren.at(0));
        m_feld.print();            

    }


}

void GameEngine::run()
{
    
       m_feld.print();
    while (!finished())
        turn();

}
