/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: stud
 *
 * Created on 25. April 2017, 12:50
 */

#include <cstdlib>

#include "GameEngine.h"

int main()
{

    vector<string> level1{
        "##########",
        "####...X.#",
        "###......#",
        "##.####..#",
        "#.....#..#",
        "#........#",
        "#........#",
        "#........#",
        "#........#",
        "##########",};

    Character* p;
    Character b = 'o';
    p = &b;

    Position pos; //start Position der Figur
    pos.Reihe = 5;
    pos.Spalte = 5;
    GameEngine ge1(10, 10, level1, p, pos);
    ge1.run();

    
    cout<<endl<<endl<<"level 2!"<<endl<<endl;
    
    vector<string> level2{
        "##########",
        "####X....#",
        "###....#.#",
        "##....#.##",
        "#....#.#.#",
        "#######.##",
        "#........#",
        "#........#",
        "#........#",
        "##########",};

    pos.Reihe = 8;
    pos.Spalte = 1;
    GameEngine ge2(10, 10, level2, p, pos);
    ge2.run();

    return 0;

}

