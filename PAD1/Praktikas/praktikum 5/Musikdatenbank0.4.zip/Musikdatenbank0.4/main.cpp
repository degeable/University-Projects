
#include <cstdlib>
#include <vector>
#include "DynArray.h"
#include "lied.h"
using namespace std;

/*
 * version 0.4
 */
int main(int argc, char** argv) {
  DynArray song;
  
void Neu(DynArray &song);
int menue(DynArray &song);
void Alle(vector<lied>&song);
void Anzeigen(DynArray &song);
void loeschen(DynArray &song);
void bearbeiten(DynArray &song);


   menue(song);
}
